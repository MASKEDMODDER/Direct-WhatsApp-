package subham.sinha.dev.DWa;
 
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.EditText;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import android.view.Display.Mode;

public class MainActivity extends Activity { 
     Button send,tst;
     EditText number,message,ccode;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MaterialTheme();
        
        setContentView(R.layout.activity_main);
		
     
        
	number=findViewById(R.id.nu);
		send=findViewById(R.id.send);
        message=findViewById(R.id.message);
        tst=findViewById(R.id.tst);
        
        ccode=findViewById(R.id.countrycode);
        GradientDrawable gd= new GradientDrawable();
        gd.setColors(new int[]{Color.parseColor("#FFA8FFB0"),Color.parseColor("#FF1DFFF2")});
        gd.setCornerRadius(50);
        gd.setOrientation(GradientDrawable.Orientation.TR_BL);
        gd.setStroke(5,Color.parseColor("#FF20293D"));
        tst.setVisibility(View.GONE);
anim(tst);

        GradientDrawable d= new GradientDrawable();
        d.setColors(new int[]{Color.parseColor("#ff0000"),Color.parseColor("#ff0000")});
        d.setCornerRadii(new float[]{50, 50, 10, 10, 50, 50, 10, 10});
        d.setOrientation(GradientDrawable.Orientation.TR_BL);
        d.setStroke(5,Color.parseColor("#FF20293D"));
        tst.setBackgroundDrawable(d);
        send.setBackgroundDrawable(gd);
        tst.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    tst.setVisibility(View.GONE);

                }
            });
        send.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
            if(ccode.getText().toString().isEmpty()&&number.getText().toString().isEmpty()){
             tst.setVisibility(View.VISIBLE);
             tst.setText("Enter Something Dude:)");
             
            }    else{
                
                
                tst.setVisibility(View.GONE);
              
                
            
                    try {
                        String url = "https://api.whatsapp.com/send?phone="+"+" +ccode.getText().toString()+ number.getText().toString() + "&text=" + URLEncoder.encode(message.getText().toString(), "UTF-8");
                  
                    Intent i=new Intent();
                    i.setAction(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);
                    } catch (UnsupportedEncodingException e) {}
               /*     Intent i=new Intent();
                    i.setAction(Intent.ACTION_VIEW);
                    i.setData(Uri.parse("https://wa.me/"+"+91"+number.getText().toString()));
                    startActivity(i);
*/
//send();}
                }}
            });
    }
	
    public void MaterialTheme(){
        int mat=Color.BLACK;
        GradientDrawable x=new GradientDrawable();
        x.setColor(mat);
       


        getWindow().setStatusBarColor(mat);
        getWindow().setNavigationBarColor(mat);
        getActionBar().setBackgroundDrawable(x);
        //     





    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            
            
            
            case R.id.exit:
                finish();
                break;
                default:
            
            
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onPictureInPictureRequested() {
        return super.onPictureInPictureRequested();
    }

    public void anim(View v){
        final float growTo = 1.2f;
        final long duration = 1200;

        ScaleAnimation grow = new ScaleAnimation(1, growTo, 1, growTo, 
                                                 Animation.RELATIVE_TO_SELF, 0.5f,
                                                 Animation.RELATIVE_TO_SELF, 0.5f);
        grow.setDuration(duration / 2);
    //    grow.setRepeatMode(1000);
       grow.setRepeatCount(1);
        ScaleAnimation shrink = new ScaleAnimation(growTo, 1, growTo, 1,
                                                   Animation.RELATIVE_TO_SELF, 0.5f,
                                                   Animation.RELATIVE_TO_SELF, 0.5f);
        shrink.setDuration(duration / 2);
        shrink.setStartOffset(duration / 2);
       // shrink.setRepeatMode(1000);
        shrink.setRepeatCount(1);
        AnimationSet growAndShrink = new AnimationSet(true);
        growAndShrink.setInterpolator(new LinearInterpolator());
        growAndShrink.addAnimation(grow);
        growAndShrink.addAnimation(shrink);
        v.startAnimation(growAndShrink);
        
        
   }
    
} 
/*
Released_By_SubhamSinha
 https://t.me/Masked_Modder
 
*/
