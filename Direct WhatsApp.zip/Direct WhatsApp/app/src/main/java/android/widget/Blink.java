package android.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader.TileMode;
import android.util.AttributeSet;
import android.widget.TextView;
import android.graphics.Color;

public class Blink extends TextView {
    private boolean mAnimating = true;
    private Matrix mGradientMatrix;
    private LinearGradient mLinearGradient;
    private Paint mPaint;
    private int mTranslate = 0;
    private int mViewWidth = 0;

    public Blink(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.mAnimating && this.mGradientMatrix != null) {
            this.mTranslate += this.mViewWidth / 10;
            if (this.mTranslate > this.mViewWidth * 2) {
                this.mTranslate = -this.mViewWidth;
            }
            this.mGradientMatrix.setTranslate((float) this.mTranslate, (float) 0);
            this.mLinearGradient.setLocalMatrix(this.mGradientMatrix);
            postInvalidateDelayed((long) 50);
        }
    }

    @Override
    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (this.mViewWidth == 0) {
            this.mViewWidth = getMeasuredWidth();
            if (this.mViewWidth > 0) {
                this.mPaint = getPaint();
                this.mLinearGradient = new LinearGradient((float) (-this.mViewWidth), (float) 0, (float) 0, (float) 0, new int[]{ Color.parseColor("#FFA8FFB0"),Color.parseColor("#FF1DFFF2"), 0}, new float[]{(float) 0, 0.5f, (float) 1}, TileMode.CLAMP);
                this.mPaint.setShader(this.mLinearGradient);
                this.mGradientMatrix = new Matrix();
            }
        }
    }
}
