package android.widget;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.MotionEvent;
import subham.sinha.dev.DWa.R;

public class _ extends EditText implements TextWatcher {
    private Drawable icClear;

    _(Context context) {
        super(context);
        init(context, (AttributeSet) null);
    }

    public _(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init(context, attributeSet);
    }

    public _(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        init(context, attributeSet);
    }

    private void init(Context context, AttributeSet attributeSet) {
        this.icClear = getResources().getDrawable(R.drawable.ic_clear);
        this.icClear.setTint(Color.BLACK);
        GradientDrawable gd= new GradientDrawable();
        gd.setColors(new int[]{Color.parseColor("#FFA8FFB0"),Color.parseColor("#FF1DFFF2")});
        gd.setCornerRadii(new float[]{50, 50, 10, 10, 50, 50, 10, 10});
        gd.setOrientation(GradientDrawable.Orientation.TR_BL);
        gd.setStroke(5,Color.parseColor("#FF20293D"));

        
     setBackgroundDrawable(gd);
        addTextChangedListener(this);
    }

    public void afterTextChanged(Editable editable) {
        Drawable[] compoundDrawables = getCompoundDrawables();
        if (length() > 0) {
            setCompoundDrawablesWithIntrinsicBounds(compoundDrawables[0], compoundDrawables[1], this.icClear, compoundDrawables[3]);
        } else {
            setCompoundDrawablesWithIntrinsicBounds(compoundDrawables[0], compoundDrawables[1], (Drawable) null, compoundDrawables[3]);
        }
    }

    public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            int x = (int) motionEvent.getX();
            if (x >= getWidth() - getCompoundPaddingRight() && x < getWidth()) {
                setText(new String());
            }
        }
        return super.onTouchEvent(motionEvent);
    }
}

